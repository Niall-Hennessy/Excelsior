package main;

public class Launcher {
    public static void main(String[] args) throws InterruptedException {
        Main.main(args);
    }
}
