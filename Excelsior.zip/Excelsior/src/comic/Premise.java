package comic;

public class Premise {

    String premise;

    public void setPremise(String toChange){
        premise = toChange;
    }

    public String getPremise(){
        return premise;
    }
}
