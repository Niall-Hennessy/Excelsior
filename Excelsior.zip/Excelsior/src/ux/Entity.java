package ux;

public enum Entity {
    rightCharacter,
    leftCharacter,
    background,
    bubble
}
